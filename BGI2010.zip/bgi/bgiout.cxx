#include <sstream>
class BGIout : virtual std::basic_ostringstream<char>
{
public:

};

BGIout bgiout;
